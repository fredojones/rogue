
class Keys:
    """ List of key inputs for the game. """
    up = 'k'
    down = 'j'
    left = 'h'
    right = 'l'
    up_left = 'y'
    up_right = 'u'
    down_left = 'b'
    down_right = 'n'

